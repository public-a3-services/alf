// background.js (service worker) - momentálne bez špeciálnych handlerov.
