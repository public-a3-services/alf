/**
 * Porovná aktuálnu URL so stepUrl.
 * - currentUrl: plná URL stránky (origin + path + query).
 * - stepUrl: len path + query (napr. "/app/.../{id}/...?krok=1"), {id} = wildcard pre ľubovoľný segment.
 * Vráti true, ak:
 *   - path po nahradení {id} sedí
 *   - všetky query parametre zo stepUrl sú prítomné v aktuálnej URL s rovnakými hodnotami
 *     (aktuálna URL môže mať navyše ďalšie parametre).
 */
function urlMatchesStep(currentUrl, stepUrl) {
  if (!currentUrl || !stepUrl) return false;
  try {
    const curr = new URL(currentUrl);
    const currentPath = curr.pathname;
    const currentSearch = curr.search || "";

    const qPos = stepUrl.indexOf("?");
    const stepPath = qPos >= 0 ? stepUrl.slice(0, qPos) : stepUrl;
    const stepSearch = qPos >= 0 ? stepUrl.slice(qPos) : "";

    const stepSegments = stepPath.split("/").filter(Boolean);
    const currSegments = currentPath.split("/").filter(Boolean);
    if (stepSegments.length !== currSegments.length) return false;

    const idIndex = stepSegments.indexOf("{id}");
    const normalizedCurr = currSegments.map((seg, i) => (i === idIndex ? "{id}" : seg)).join("/");
    const normalizedPath = "/" + normalizedCurr + currentSearch;
    const stepPathAndQuery = (stepPath.startsWith("/") ? stepPath : "/" + stepPath) + stepSearch;

    // Path (vrátane query stringu) musí mať rovnakú štruktúru, ale query môže mať v currentUrl
    // ďalšie parametre navyše – stačí, že všetky parametre zo stepUrl sú prítomné.
    if (stepPath.startsWith("/")) {
      if (!normalizedPath.startsWith(stepPath)) {
        return false;
      }
    }

    if (!stepSearch) {
      // stepUrl nemá query – stačí zhodná path (už overená vyššie cez segments)
      return true;
    }

    const stepParams = new URLSearchParams(stepSearch);
    const currParams = new URLSearchParams(currentSearch);

    for (const [key, value] of stepParams.entries()) {
      if (!currParams.has(key)) return false;
      // ak v stepUrl je konkrétna hodnota, musí sedieť
      if (value !== "" && currParams.get(key) !== value) {
        return false;
      }
    }

    return true;
  } catch (e) {
    return false;
  }
}

function autofillScenarioForCurrentUrl(scenario) {
  if (!Array.isArray(scenario) || !scenario.length) {
    return { filledCount: 0, matchedStepUrl: null };
  }

  const currentUrl = location.href;

  for (const step of scenario) {
    if (!step || !step.url || !step.map || typeof step.map !== "object") continue;
    const stepUrl = String(step.url).trim();
    if (!urlMatchesStep(currentUrl, stepUrl)) continue;

    const entries = Object.entries(step.map);
    let filledCount = 0;
    let scheduledRestAfterToggle = false;

    const fillEntry = (dataTestId, value) => {
      if (dataTestId == null || dataTestId === "") return false;

      const rawKey = String(dataTestId);
      const hashPos = rawKey.indexOf("#");
      const lookupKey = hashPos >= 0 ? rawKey.slice(0, hashPos) : rawKey;
      const isToggleKeyLocal =
        hashPos >= 0 && rawKey.slice(hashPos + 1).toLowerCase().startsWith("toggle");

      const selectorId =
        typeof CSS !== "undefined" && CSS.escape ? CSS.escape(lookupKey) : lookupKey;
      const el = document.querySelector(`[data-test-id="${selectorId}"]`);
      if (!el) return false;

      const valueStr = value != null ? String(value) : "";

      // Rozlíšenie podľa typu elementu
      if (el instanceof HTMLInputElement) {
        const t = el.type ? el.type.toLowerCase() : "";

        if (t === "checkbox" || t === "radio") {
          if (typeof el.click === "function") {
            el.click();
          }
          filledCount++;
          return true;
        } else {
          el.value = valueStr;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
        }
      } else if (el instanceof HTMLTextAreaElement) {
        el.value = valueStr;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (el instanceof HTMLSelectElement) {
        el.value = valueStr;
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if ("value" in el) {
        // Iné elementy s .value (napr. custom komponenty)
        el.value = valueStr;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        // Pre wrappery (napr. div/span s data-test-id):
        if (el.querySelector) {
          // 1) Toggle: vnorený checkbox/radio/role=checkbox
          if (isToggleKeyLocal) {
            const innerToggle = el.querySelector(
              'input[type="checkbox"], input[type="radio"], [role="checkbox"]',
            );
            if (innerToggle && typeof innerToggle.click === "function") {
              innerToggle.click();
              filledCount++;
              return true;
            }
          }

          // 2) Combobox (custom multiselect) – vyber možnosť podľa textu/aria-label
          const comboboxRoot =
            el.getAttribute("role") === "combobox"
              ? el
              : el.querySelector('[role="combobox"], .multiselect-wrapper');
          if (comboboxRoot) {
            const listbox =
              el.querySelector(".multiselect-options") ||
              el.querySelector('[role="listbox"]') ||
              comboboxRoot.nextElementSibling;
            if (listbox) {
              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );
              const target = options.find((opt) => {
                const labelText =
                  (opt.getAttribute && opt.getAttribute("aria-label")) ||
                  opt.textContent ||
                  "";
                const id = opt.id || "";
                // napr. "...-multiselect-option-vydatazenaty" -> "vydatazenaty"
                let idValue = "";
                const idParts = id.split("-option-");
                if (idParts.length === 2) {
                  idValue = idParts[1];
                }

                const wanted = valueStr.trim().toLowerCase();
                const labelNorm = labelText.trim().toLowerCase();
                const idNorm = idValue.trim().toLowerCase();

                return wanted === labelNorm || (idNorm && wanted === idNorm);
              });

              if (target && typeof target.click === "function") {
                target.click();
                filledCount++;
                return true;
              }
            }
          }
        }

        // Fallback – pre obyčajné wrappery bez špeciálnej logiky
        el.textContent = valueStr;
      }
      filledCount++;
      return true;
    };

    entries.forEach(([dataTestId, value], index) => {
      const keyStr = dataTestId != null ? String(dataTestId) : "";
      const hashIndex = keyStr.indexOf("#");
      const isToggleKey =
        hashIndex >= 0 && keyStr.slice(hashIndex + 1).toLowerCase().startsWith("toggle");

      if (isToggleKey && !scheduledRestAfterToggle) {
        fillEntry(dataTestId, value);
        scheduledRestAfterToggle = true;

        // Po zapnutí toggle počkáme 1s, aby sa odomkli ďalšie polia,
        // a potom pokračujeme vo vyplňovaní zvyšných viet kľúčov v poradí.
        setTimeout(() => {
          try {
            for (let i = index + 1; i < entries.length; i++) {
              const [nextKey, nextValue] = entries[i];
              fillEntry(nextKey, nextValue);
            }
          } catch (e) {
            console.error("ALF scenario autofill – delayed fill error", e);
          }
        }, 1000);
      } else {
        fillEntry(dataTestId, value);
      }
    });

    if (filledCount > 0) {
      return { filledCount, matchedStepUrl: stepUrl };
    }

    break;
  }

  return { filledCount: 0, matchedStepUrl: null };
}

// Spracovanie akcií zo scenára z DevTools (ALF)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "ALF_RUN_SCENARIO_ACTION") {
    return;
  }

  const scenario = message.scenario;
  const stepIndex = message.stepIndex;
  if (!Array.isArray(scenario) || stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
    sendResponse && sendResponse({ ok: false, reason: "missing_scenario_or_index" });
    return;
  }

  const stepForClick = scenario[stepIndex];
  const actionName = stepForClick.action || stepForClick.actions;
  if (!actionName) {
    sendResponse && sendResponse({ ok: false, reason: "missing_action" });
    return;
  }

  try {
    let handledAutofill = false;

    const { filledCount } = autofillScenarioForCurrentUrl(scenario);
    if (filledCount > 0) {
      handledAutofill = true;
    }

    // 2) Klik na element podľa action kroku na stepIndex (krok, ktorý sa má vykonať)
    const selector = `[data-test-id="${actionName}"]`;
    const all = Array.prototype.slice.call(document.querySelectorAll("[data-test-id]"));
    const matches = Array.prototype.slice.call(document.querySelectorAll(selector));

    console.log("ALF content – action click", {
      stepIndex,
      actionName,
      selector,
      matchCount: matches.length,
      allIdsSample: all.slice(0, 50).map((el) => el.getAttribute("data-test-id")),
    });

    let clicked = false;
    if (matches[0]) {
      const candidate = matches[0];
      const clickable =
        (typeof candidate.click === "function" && candidate) ||
        candidate.querySelector(
          'button, [role="button"], a, input[type="submit"], input[type="button"]',
        );

      if (clickable && typeof clickable.click === "function") {
        clickable.click();
        clicked = true;
      }
    }

    // 3) Po krátkom čase po CLick skúsime ešte raz autofill – pre prípad, že sa navigovalo na novú URL
    //    (typický flow: Action -> nová stránka -> automatický autofill podľa map).
    setTimeout(() => {
      try {
        autofillScenarioForCurrentUrl(scenario);
      } catch (e) {
        console.error("ALF content script – chyba pri delayed autofill:", e);
      }
    }, 800);

    sendResponse &&
      sendResponse({
        ok: true,
        found: !!matches[0],
        clicked,
        autofilled: handledAutofill,
        matchCount: matches.length,
        allIdsSample: all.slice(0, 50).map((el) => el.getAttribute("data-test-id")),
      });
  } catch (e) {
    console.error("ALF content script – chyba pri spracovaní scenára:", e);
    sendResponse && sendResponse({ ok: false, error: String(e) });
  }

  // keep channel open only synchronously
  return true;
});

