
let lastUrl = location.href;

function runAutofill() {
  if (window.autofill && typeof window.autofill.applyAutofillForCurrentUrl === "function") {
    window.autofill.applyAutofillForCurrentUrl();
  } else {
    console.error("ALF autofill – funkcia applyAutofillForCurrentUrl nie je dostupná.");
  }
}

// Jednoduchší a spoľahlivejší spôsob: pollujeme location.href
setInterval(() => {
  if (location.href !== lastUrl) {
    const oldUrl = lastUrl;
    const newUrl = location.href;
    lastUrl = newUrl;
    console.log("URL sa zmenila na SPA:", { oldUrl, newUrl });
    runAutofill();
  }
}, 500);

// Spusti autofill aj pri prvom načítaní
runAutofill();

